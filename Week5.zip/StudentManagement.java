public class StudentManagement {
    /**
     * Qua di nan ni day.
     */
    public static boolean sameGroup(Student s1, Student s2) {
        if ((s1.getGroup()).equals(s2.getGroup())) {
            return true;
        }
        return false;
    }

    /**
     * Qua di nan ni day.
     */
    public Student[] students = new Student[100];
    public int count = 0;

    /**
     * Qua di nan ni day.
     */
    public void addStudent(Student newStudent) {
        students[count] = newStudent;
        count++;
    }

    /**
     * Qua di nan ni day.
     */
    public String studentsByGroup() {
        String a = "";
        boolean[] x = new boolean[count];
        for (int i = 0; i < count; i++) {
            x[i] = true;
        }
        for (int i = 0; i < count; i++) {
            if (x[i] == true) {
                a = a + students[i].getGroup() + "\n";
            }
            for (int j = i; j < count; j++) {
                if (x[j] == true && (students[j].getGroup()).equals(students[i].getGroup())) {
                    a = a + students[j].getInfo() + "\n";
                    x[j] = false;
                }

            }
        }
        return a;
    }

    /**
     * Qua di nan ni day.
     */
    public void removeStudent(String id) {
        for (int i = 0; i < count; i++) {
            if ((students[i].getId()).equals(id)) {
                for (int j = i; j < count - 1; j++) {
                    students[j] = students[j + 1];
                }
            }
        }
        count--;
    }
}
