#include<stdio.h>
#include<stdlib.h>
#include<string.h>
struct nhanvien {
	char name[30];
	int age;
};
typedef struct nhanvien nv;
void nhap(nv *new) {
	printf("\nNhap ho va ten nhan vien : ");
	scanf("%[^\n]",new->name);
	getchar();
	printf("\nNhap tuoi nhan vien : ");
	scanf("%d",&new->age);
	getchar();
}
void xuat(nv new) {
	printf("Ho va ten nhan vien : %s",new.name);
	printf("\nTuoi nhan vien : %d",new.age);
}
int main() {
	nv *cty = (nv*)malloc(5*sizeof(nv));
	
	for(int i = 0;i<4;i++) {
		nhap(&cty[i]);
	}
	for(int i = 0;i<4;i++) {
		xuat(cty[i]);
	}
	free(cty);
	return 0;
}
