#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main() {
	char s[100];
	int b[10] = {0};
	fgets(s , sizeof(s) , stdin);
	for(int i = 0;i<strlen(s);i++) {
		if(s[i] >= 48 && s[i] <= 57) {
			b[s[i]-'0']++;
		} 
	}
	for(int i = 0;i<10;i++) {
		printf("%d ",b[i]);
	}
	return 0;
}
