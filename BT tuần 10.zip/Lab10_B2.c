#include <stdio.h>
#include <stdlib.h>

struct  thisinh {
    char sbd[5];
	char name[25];
    char gt[5];
    double diemtoan;
    double diemly;
    double diemanhvan;
    int diemtong;   
};
typedef struct thisinh ts ;
int tong(ts new) {
	new.diemtong = (int)(new.diemanhvan + new.diemly + new.diemtoan);
	return new.diemtong;
}


//Cau 1
void nhap(ts *new) {
	printf("Nhap sbd : ");
	scanf("%s",new->sbd);
	getchar();
	printf("Nhap ho va ten : ");
	scanf("%[^\n]",new->name);
	getchar();
	printf("Nhap diem toan : ");
	scanf("%lf",&new->diemtoan);
	printf("Nhap diem ly : ");
	scanf("%lf",&new->diemly);
	printf("Nhap diem anh van : ");
	scanf("%lf",&new->diemanhvan);
}
void xuat(ts new) {
	printf("Sbd : %s\n",new.sbd);
	
	printf("Ho va ten : %s\n",new.name);
	
	printf("Diem toan : %.2lf\n",new.diemtoan);
	
	printf("Diem ly : %.2lf\n",new.diemly);
	
	printf("Diem anh van : %.2lf\n",new.diemanhvan);
	
	printf("Diem tong : %d\n",tong(new));
}
int main() {
	int n;
	printf("Nhap so luong thi sinh : ");
	scanf("%d",&n);
	ts *lop = (ts*)malloc(n*sizeof(ts));
	for(int i = 0;i<n;i++) {
		nhap(&lop[i]);
	}
	for(int i = 0;i<n;i++) {
		if(tong(lop[i]) >= 18 && lop[i].diemanhvan >= 5 && lop[i].diemly >= 5 && lop[i].diemtoan >= 5) xuat(lop[i]);
	} //cau2
	
	
	return 0;
}

